

<?php $__env->startSection('content'); ?>
<h1>Hello, welcome to the Home Page!</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Teknologi Informasi Laravel\Kukuh_TIII\resources\views/home.blade.php ENDPATH**/ ?>