@extends('layouts.main')

@section('content')
<h1>Hello, welcome to the Home Page!</h1>

@endsection